<?php

$left="{";
$right="}";
$win="tCTF";
$hello="world";
$world="cuc";
$cuc="good";
$good="you";
$you="win";

$host = $_SERVER['HTTP_HOST'];

echo $$$$$$hello . $left . md5($host) . $right;

